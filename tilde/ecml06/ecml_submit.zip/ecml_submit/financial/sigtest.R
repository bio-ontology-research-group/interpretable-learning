ar1 <- c()
ar2 <- c(1.0,1.0,0.75,0.85507,1.0,0.57639,0.75,0.75,1.0,0.75)
t.test(ar1,ar2,"two.sided",paired=TRUE)
